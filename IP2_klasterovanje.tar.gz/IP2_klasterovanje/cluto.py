import sys
import pandas as pd
import re
import collections
import numpy as np
from sklearn import datasets
import matplotlib.pyplot as plt

def main():
    
    podaci = pd.read_csv("obradjeni_podaci.csv")
    if sys.argv[1] == 'celije':
        podaci = podaci.T
    
    print(podaci.shape)
    podaci = podaci.values
    
    with open("podaci.mat" , "w" ) as f:
        f.write(str(podaci.shape[0]) + " " + str(podaci.shape[1]) + "\n" )
        for i in range (podaci.shape[0]) :
            for j in range (podaci.shape[1]) :
                f.write(str(podaci[i][j]) + " ")
            f.write("\n")
                    
                    
if __name__ == '__main__':
    main()
                    