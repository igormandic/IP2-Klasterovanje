import pandas as pd
import numpy as np
import csv
import collections
import itertools
import matplotlib.pyplot as plt
from minisom import MiniSom    
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import KElbowVisualizer

def ucitavanje_i_predprocesiranje_podataka():
  
  podaci = open('006_Lymphoblastoid_cell_line_GM12891_csv.csv', "r")
  lista_podataka = [row for row in csv.reader(podaci)]
  broj_redova_sa_svim_nulama = 0
  broj_redova_bez_nula = 0
  
  br_redova = len(lista_podataka)
  br_kolona = len(lista_podataka[0])
  print('Broj redova pre pretprocesiranja: {}'.format(br_redova))
  print('Broj kolona: {}'.format(br_kolona))
  lista_gena = []
  with open('obradjeni_podaci.csv', mode='w') as fajl_pisanje:
    obradjeni_podaci = csv.writer(fajl_pisanje, delimiter=',', quotechar='"', 
                                  quoting=csv.QUOTE_MINIMAL)
    for i in range(1, br_redova):
      br_nula_po_redu = 0
      for j in range(1, br_kolona):
        if int(lista_podataka[i][j]) == 0:
          br_nula_po_redu += 1
      if br_nula_po_redu == br_kolona - 1:
        broj_redova_sa_svim_nulama += 1
      else:
        broj_redova_bez_nula += 1
        lista_gena.append(lista_podataka[i][0])
        obradjeni_podaci.writerow(lista_podataka[i][1: ])
        
        
  
  print('Broj izbacenih redova nakon pretprocesiranja: {}'.format(broj_redova_sa_svim_nulama))
  print('Broj redova nakon pretprocesiranja: {}'.format(broj_redova_bez_nula))
  return lista_gena



def main():
  lista_gena = []
  lista_gena = ucitavanje_i_predprocesiranje_podataka()
  
  
if __name__ == '__main__':
  main()
