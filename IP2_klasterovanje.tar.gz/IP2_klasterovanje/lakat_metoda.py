import sys
import pandas as pd
import numpy as np
import csv
import collections
import itertools
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import KElbowVisualizer

def lakat_metoda(indikator):
  model = KMeans()
  vizuelizator = KElbowVisualizer(model, k =(10, 40))
  
  podaci = pd.read_csv('obradjeni_podaci.csv')
  if indikator == 'celije':
    podaci = podaci.T

  podaci = podaci.values

  vizuelizator.fit(podaci)
  vizuelizator.poof 
  
def main():
  lakat_metoda(sys.argv[1])
  
if __name__ == '__main__':
  main()
