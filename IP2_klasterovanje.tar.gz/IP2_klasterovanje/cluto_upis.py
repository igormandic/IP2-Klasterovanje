import pandas as pd
import numpy as np
import csv
import sys
import itertools


def izlaz_kluto(indikator):
  podaci = open('geni.csv', 'r')
  geni = []

  datoteka = ''
  if indikator == 'geni':
    podaci = open('geni.csv', 'r')
    geni = [row for row in csv.reader(podaci)][0]
    mapa = {'0':[], '1':[], '2':[], '3':[], '4':[], '5':[], '6':[], '7':[]}
    datoteka = 'podaci.mat.clustering.8'
  elif indikator == "celije":
    mapa = {'0':[], '1':[], '2':[], '3':[], '4':[], '5':[], '6':[]}
    datoteka = 'transponovani_podaci.mat.clustering.7'
    
  with open(datoteka, 'r') as f:
    linije = f.readlines()
    i = 0
    for linija in linije:
      if linija[0] != "-":
        if geni != []:
          mapa[linija[0]].append(geni[i])
        else:
          mapa[linija[0]].append(i)
      i += 1
              
  with open('CLUTO_rezultati/klasterovani_celije_cluto2.txt', 'w') as f:
    for kljuc, vrednosti in mapa.items():
      f.write(str(kljuc) + '\n' + '[')
      for vrednost in vrednosti:
        f.write(str(vrednost) + ', ')
      f.write(']\n\n')
			
def main():
  print(sys.argv[1])
  izlaz_kluto(sys.argv[1])
  
  
if __name__ == '__main__':
  main()