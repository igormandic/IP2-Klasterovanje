import sys
import pandas as pd
import numpy as np
import csv
import collections
import itertools
import matplotlib.pyplot as plt
from minisom import MiniSom    
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import KElbowVisualizer


def ucitavanje_i_predprocesiranje_podataka():
  
  podaci = open('006_Lymphoblastoid_cell_line_GM12891_csv.csv', "r")
  lista_podataka = [row for row in csv.reader(podaci)]
  broj_redova_sa_svim_nulama = 0
  broj_redova_bez_nula = 0
  
  br_redova = len(lista_podataka)
  br_kolona = len(lista_podataka[0])
  print('Broj redova pre pretprocesiranja: {}'.format(br_redova))
  print('Broj kolona: {}'.format(br_kolona))
  lista_gena = []
  with open('obradjeni_podaci.csv', mode='w') as fajl_pisanje:
    obradjeni_podaci = csv.writer(fajl_pisanje, delimiter=',', quotechar='"', 
                                  quoting=csv.QUOTE_MINIMAL)
    for i in range(1, br_redova):
      br_nula_po_redu = 0
      for j in range(1, br_kolona):
        if int(lista_podataka[i][j]) == 0:
          br_nula_po_redu += 1
      if br_nula_po_redu == br_kolona - 1:
        broj_redova_sa_svim_nulama += 1
      else:
        broj_redova_bez_nula += 1
        lista_gena.append(lista_podataka[i][0])
        obradjeni_podaci.writerow(lista_podataka[i][1: ])
        
        
  
  print('Broj izbacenih redova nakon pretprocesiranja: {}'.format(broj_redova_sa_svim_nulama))
  print('Broj redova nakon pretprocesiranja: {}'.format(broj_redova_bez_nula))
  return lista_gena


def ispisivanje_rezultata_u_datoteku(ime, podaci, klasteri, broj_gena_po_klasteru,
                                     lista_gena, broj_klastera):
  with open(ime, mode='w') as fajl_pisanje:
    fajl_pisanje.write('KLASTEROVANJE ALGORITMOM K SREDINA')
    fajl_pisanje.write('\n\n')
    
    fajl_pisanje.write('broj klastera = {}'.format(broj_klastera))
    fajl_pisanje.write('\n\n')
    
    fajl_pisanje.write('Rasporedjenost po klasterima:')
    fajl_pisanje.write('\n\n')
     
    for k in broj_gena_po_klasteru:
      if k == -1:
        fajl_pisanje.write('Broj elemenata van granice: {}'.format(broj_gena_po_klasteru[k]))
      else:
        fajl_pisanje.write('Klaster {}: {}'.format(k, broj_gena_po_klasteru[k]))
      fajl_pisanje.write('\n')
    
    fajl_pisanje.write('\n')
    
    kvalitet = silhouette_score(podaci, klasteri, metric='euclidean')
    fajl_pisanje.write('Kvalitet klasterovanja je: {}'.format(str(kvalitet)))

    fajl_pisanje.write('\n\n')
    
    fajl_pisanje.write('Elementi u svakom klasteru:')
    fajl_pisanje.write('\n\n')
    broj_gena = len(podaci)
    if lista_gena != []:
      broj_gena = len(lista_gena)
    
    vrednosti = [x for x in range(broj_gena)]
    lista_parova = pd.DataFrame({'klaster' : klasteri,
                                 'vrednosti' : vrednosti})
    
    grupisani_klasteri = lista_parova.groupby('klaster')['vrednosti'].apply(pd.Series.tolist).tolist()
    n = len(grupisani_klasteri)
    print(n)
    
    for i in range(n):
      fajl_pisanje.write('Klaster {}:'.format(i))
      fajl_pisanje.write('\n\n')
      
      lista = grupisani_klasteri[i]
      l = len(lista)
      for j in range(l):
        if lista_gena != []:
          fajl_pisanje.write(lista_gena[lista[j]])
        else:
          fajl_pisanje.write(str(lista[j]))
        fajl_pisanje.write('\n')
      fajl_pisanje.write('\n\n')


def k_sredina(podaci, broj_klastera, lista_gena):
  
  model = KMeans(n_clusters = broj_klastera, n_init = 15).fit(podaci)
  klasteri = model.labels_
  
  broj_gena_po_klasteru = collections.Counter(klasteri)
  putanja = 'klasterovanje_celija_k_sredina.txt'
  ispisivanje_rezultata_u_datoteku(putanja, podaci, klasteri, 
                                   broj_gena_po_klasteru, lista_gena, broj_klastera)
      

def main():
  lista_gena = []  
  podaci = open('obradjeni_podaci.csv', "r")
  lista_podataka = [row for row in csv.reader(podaci)]
  
  if sys.argv[1] == "geni":
    lista_gena = ucitavanje_i_predprocesiranje_podataka()
    k_sredina(lista_podataka, 22, lista_gena)
  elif sys.argv[1] == "celije":
    transponovani_podaci = [list(i) for i in zip(*lista_podataka)]
    k_sredina(transponovani_podaci, 22, lista_gena)
  else:
    print('Pogresan unos!')
  
if __name__ == '__main__':
  main()
