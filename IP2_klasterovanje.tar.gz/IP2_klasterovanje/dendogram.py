import sys
import pandas as pd
import numpy as np
import csv
import collections
import itertools
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN

def nacrtaj_dendogram(indikator):
  podaci = pd.read_csv('/content/gdrive/My Drive/IP/obradjeni_podaci.csv')
  
  if indikator == "celije":
    podaci = podaci.T
  
  matrica_povezanosti = linkage(podaci, 'ward')
  slika = plt.figure(figsize=(7.5, 5))
  dendrogram(matrica_povezanosti, color_threshold=10000)

  plt.title('Dendogram za hijararhijsko klasterovanje celija (Ward)')
  plt.xlabel('indeks')
  plt.ylabel('razdaljina')
  plt.tight_layout()


    

def main():
  nacrtaj_dendogram(sys.argv[1])
  
if __name__ == "__main__":
  main()